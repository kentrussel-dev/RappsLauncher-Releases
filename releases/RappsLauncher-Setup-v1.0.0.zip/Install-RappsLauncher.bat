@echo off
title Rapps Launcher Installer
echo =======================================================
echo          Installing Rapps Launcher v1.0.0
echo =======================================================
echo.
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0Install-RappsLauncher.ps1"
echo.
pause
