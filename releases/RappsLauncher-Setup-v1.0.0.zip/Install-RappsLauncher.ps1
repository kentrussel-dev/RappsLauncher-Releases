$ErrorActionPreference = "Stop"

$appName = "Rapps Launcher"
$installFolder = "$env:LOCALAPPDATA\Programs\RappsLauncher"

Write-Host "==> Installing $appName to $installFolder..." -ForegroundColor Cyan

if (-not (Test-Path $installFolder)) {
    New-Item -ItemType Directory -Path $installFolder -Force | Out-Null
}

Get-ChildItem -Path $PSScriptRoot -Exclude "Install-*" | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $installFolder -Recurse -Force
}

$exePath = Join-Path $installFolder "RappsLauncher.exe"
$iconPath = Join-Path $installFolder "Assets\app_icon.ico"
if (-not (Test-Path $iconPath)) { $iconPath = $exePath }

$ws = New-Object -ComObject WScript.Shell

# 1. Start Menu Shortcut
$startMenuPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\$appName.lnk"
$sc1 = $ws.CreateShortcut($startMenuPath)
$sc1.TargetPath = $exePath
$sc1.WorkingDirectory = $installFolder
$sc1.IconLocation = "$iconPath,0"
$sc1.Description = "$appName - Workflow Workspace Launcher"
$sc1.Save()

# 2. Desktop Shortcut
$desktopPath = "$env:USERPROFILE\Desktop\$appName.lnk"
$sc2 = $ws.CreateShortcut($desktopPath)
$sc2.TargetPath = $exePath
$sc2.WorkingDirectory = $installFolder
$sc2.IconLocation = "$iconPath,0"
$sc2.Description = $appName
$sc2.Save()

# 3. Startup Shortcut
$startupPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\$appName.lnk"
$sc3 = $ws.CreateShortcut($startupPath)
$sc3.TargetPath = $exePath
$sc3.WorkingDirectory = $installFolder
$sc3.IconLocation = "$iconPath,0"
$sc3.Description = "$appName Startup"
$sc3.Save()

Write-Host "==> Installation complete!" -ForegroundColor Green
Write-Host " - Start Menu Shortcut: $startMenuPath" -ForegroundColor Gray
Write-Host " - Desktop Shortcut:    $desktopPath" -ForegroundColor Gray
Write-Host " - Windows Startup:     $startupPath" -ForegroundColor Gray
Write-Host ""
Write-Host "==> Launching $appName..." -ForegroundColor Cyan
Start-Process -FilePath $exePath
